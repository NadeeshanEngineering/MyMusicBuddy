//
//  CustomExtensions.swift
//  MyMusicBuddy
//
//  Created by Nadeeshan on 2/22/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import Foundation
import UIKit
import CoreData

extension UIImage {
    func setImage(_ name: String) -> Bool {
        guard let data = self.jpegData(compressionQuality: 1) ?? self.pngData() else {
            return false
        }
        guard let directory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) as NSURL else {
            return false
        }
        do {
            try data.write(to: directory.appendingPathComponent("\(name).png")!)
            return true
        } catch {
            print(error.localizedDescription)
            return false
        }
    }
}

extension String {
    func getImage() -> UIImage? {
        if let dir = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) {
            return UIImage(contentsOfFile: URL(fileURLWithPath: dir.absoluteString).appendingPathComponent("\(self).png").path)
        }
        return nil
    }
    
    func asEntity() -> NSManagedObject {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: self, in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        return newUser
    }
}

