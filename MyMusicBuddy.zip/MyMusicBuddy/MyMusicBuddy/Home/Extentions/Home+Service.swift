//
//  Home+Service.swift
//  MyMusicBuddy
//
//  Created by Alagarasan Mahalingam on 2/21/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import Foundation
import UIKit

extension HomeTableViewController {
    func sendRequest() {
        let session = URLSession.shared
        let url = URL(string: Constance().base_url + "/search?term=jack+johnson&limit=25")!
        let task = session.dataTask(with: url) { (data, _, _) -> Void in
            if let data = data {
                self.decodeMusicList(json: data, completion: {
                    (musicList, error) in
                    
                    guard let resource = musicList else {
                        print("Error: \(error!.localizedDescription)")
                        return
                    }
                    
                    print("decoded list: \(resource)")
                    self.handleResponse(resource)
                })
            }
        }
        task.resume()
    }
    
    private func handleResponse(_ data: [MusicList]) {
//        self.tMusicList = data
//        DispatchQueue.main.async {
//            self.tableView.reloadData()
//        }
        
        for item in data {
            musicEntity.setValue(item.artistId, forKey: "artistId")
            musicEntity.setValue(item.artistNam, forKey: "artistNam")
            musicEntity.setValue(item.artistViewUrl, forKey: "artistViewUrl")
            musicEntity.setValue(item.artworkUrl100, forKey: "artworkUrl100")
            musicEntity.setValue(item.artworkUrl30, forKey: "artworkUrl30")
            musicEntity.setValue(item.artworkUrl60, forKey: "artworkUrl60")
            musicEntity.setValue(item.collectionCensoredName, forKey: "collectionCensoredName")
            musicEntity.setValue(item.collectionExplicitness, forKey: "collectionExplicitness")
            musicEntity.setValue(item.collectionId, forKey: "collectionId")
            musicEntity.setValue(item.collectionName, forKey: "collectionName")
            musicEntity.setValue(item.trackName, forKey: "trackName")
            musicEntity.setValue(item.collectionCensoredName, forKey: "collectionCensoredName")
            musicEntity.setValue(item.trackCensoredName, forKey: "trackCensoredName")
            musicEntity.setValue(item.artistViewUrl, forKey: "artistViewUrl")
            musicEntity.setValue(item.collectionViewUrl, forKey: "collectionViewUrl")
            musicEntity.setValue(item.trackViewUrl, forKey: "trackViewUrl")
            musicEntity.setValue(item.previewUrl, forKey: "previewUrl")
            musicEntity.setValue(item.artworkUrl30, forKey: "artworkUrl30")
            musicEntity.setValue(item.artworkUrl60, forKey: "artworkUrl60")
            musicEntity.setValue(item.artworkUrl100, forKey: "artworkUrl100")
            musicEntity.setValue(item.collectionPrice, forKey: "collectionPrice")
            musicEntity.setValue(item.trackPrice, forKey: "trackPrice")
            musicEntity.setValue(item.releaseDate, forKey: "releaseDate")
            musicEntity.setValue(item.collectionExplicitness, forKey: "collectionExplicitness")
            musicEntity.setValue(item.trackExplicitness, forKey: "trackExplicitness")
            musicEntity.setValue(item.discCount, forKey: "discCount")
            musicEntity.setValue(item.discNumber, forKey: "discNumber")
            musicEntity.setValue(item.trackCount, forKey: "trackCount")
            musicEntity.setValue(item.trackNumber, forKey: "trackNumber")
            musicEntity.setValue(item.trackTimeMillis, forKey: "trackTimeMillis")
            musicEntity.setValue(item.country, forKey: "country")
            musicEntity.setValue(item.currency, forKey: "currency")
            musicEntity.setValue(item.primaryGenreName, forKey: "primaryGenreName")
            musicEntity.setValue(item.isStreamable, forKey: "isStreamable")
        }
    }
    
    private func decodeMusicList(json: Data, completion: @escaping (_ data: [MusicList]?, _ error: Error?) -> Void) {
        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let base = try decoder.decode(Base.self, from: json)
            return completion(base.results, nil)
        } catch let error {
            print("Error creating current weather from JSON because: \(error.localizedDescription)")
            return completion(nil, error)
        }
    }
}

extension HomeTableViewCell {
    func sendRequestForArtwork(url urltext: String?, imagename: String) {
        let session = URLSession.shared
        let url = URL(string: urltext!)!
        let task = session.dataTask(with: url) { (data, _, _) -> Void in
            if let data = data {
                let artwork = UIImage(data: data) ?? UIImage()
                if artwork.setImage(imagename) == false {
                    print("Error: Faild to store artwork \(imagename).png")
                    return
                }
                self.handleResponseForArtwork(name: imagename)
            }
        }
        task.resume()
    }
    
    private func handleResponseForArtwork(name: String) {
        DispatchQueue.main.async {
            self.artworkImgView.image = name.getImage()
            self.artworkImgView.layer.cornerRadius = 20
            self.artworkImgView.layer.masksToBounds = true
        }
    }
}
