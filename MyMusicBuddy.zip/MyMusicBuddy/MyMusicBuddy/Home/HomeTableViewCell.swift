//
//  HomeTableViewCell.swift
//  MyMusicBuddy
//
//  Created by Alagarasan Mahalingam on 2/21/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet var artworkImgView: UIImageView!
    @IBOutlet var trackNameLbl: UILabel!
    @IBOutlet var collectionNameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
