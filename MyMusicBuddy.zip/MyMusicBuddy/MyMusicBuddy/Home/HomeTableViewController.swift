//
//  HomeTableViewController.swift
//  MyMusicBuddy
//
//  Created by Alagarasan Mahalingam on 2/21/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {

    var tMusicList = [MusicList]()
    let musicEntity = "Music".asEntity()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.sendRequest()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return tMusicList.count
    }
 
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "homeCell", for: indexPath) as! HomeTableViewCell
        cell.trackNameLbl.text = tMusicList[indexPath.row].trackName ?? ""
        cell.collectionNameLbl.text = tMusicList[indexPath.row].collectionName ?? ""
        DispatchQueue.main.async {
            cell.sendRequestForArtwork(url: self.tMusicList[indexPath.row].artworkUrl100, imagename: String(self.tMusicList[indexPath.row].trackId))
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "detailViewOpenSegue", sender: self.tMusicList[indexPath.row])
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailViewOpenSegue" {
            let detailViewController = segue.destination as? DetailViewController
            detailViewController?.tMusicList = sender as? MusicList
        }
    }
}
