//
//  DetailViewController.swift
//  MyMusicBuddy
//
//  Created by Alagarasan Mahalingam on 2/21/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet var artworkImgView: UIImageView!
    @IBOutlet var trackNameLbl: UILabel!
    @IBOutlet var collectionNameLbl: UILabel!
    @IBOutlet var artistNameLbl: UILabel!
    @IBOutlet var priceLbl: UILabel!
    @IBOutlet var releaseDateLbl: UILabel!
    
    var tMusicList: MusicList!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.setUIView()
    }
    
    private func setUIView() {
        self.trackNameLbl.text = self.tMusicList.trackName ?? ""
        self.collectionNameLbl.text = self.tMusicList.collectionName ?? ""
        self.artistNameLbl.text = self.tMusicList.artistNam ?? ""
        self.priceLbl.text = "\(self.tMusicList.currency!) \(self.tMusicList.collectionPrice!)"
        self.releaseDateLbl.text = self.tMusicList.releaseDate ?? ""
        
        self.artworkImgView.image = String(self.tMusicList.trackId).getImage()
        self.artworkImgView.layer.cornerRadius = 20
        self.artworkImgView.layer.masksToBounds = true
    }


}

