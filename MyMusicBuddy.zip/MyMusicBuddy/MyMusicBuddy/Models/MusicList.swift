//
//  MusicList.swift
//  MyMusicBuddy
//
//  Created by Alagarasan Mahalingam on 2/21/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import Foundation
import UIKit

struct Base: Decodable {
    var resultCount: Int!
    var results: [MusicList]
}

struct MusicList: Decodable {

    let wrapperType: String!
    let kind: String!
    let artistId: Int!
    let collectionId: Int!
    let trackId: Int!
    let artistNam: String!
    let collectionName: String!
    let trackName: String!
    let collectionCensoredName: String!
    let trackCensoredName: String!
    let artistViewUrl: String!
    let collectionViewUrl: String!
    let trackViewUrl: String!
    let previewUrl: String!
    let artworkUrl30: String!
    let artworkUrl60: String!
    let artworkUrl100: String!
    let collectionPrice: Float!
    let trackPrice: Float!
    let releaseDate: String!
    let collectionExplicitness: String!
    let trackExplicitness: String!
    let discCount: Int!
    let discNumber: Int!
    let trackCount: Int!
    let trackNumber: Int!
    let trackTimeMillis: Int!
    let country: String!
    let currency: String!
    let primaryGenreName: String!
    let isStreamable: Bool!
    
    enum CodingKeys: String, CodingKey {
        case wrapperType
        case kind
        case artistId
        case collectionId
        case trackId
        case artistNam
        case collectionName
        case trackName
        case collectionCensoredName
        case trackCensoredName
        case artistViewUrl
        case collectionViewUrl
        case trackViewUrl
        case previewUrl
        case artworkUrl30
        case artworkUrl60
        case artworkUrl100
        case collectionPrice
        case trackPrice
        case releaseDate
        case collectionExplicitness
        case trackExplicitness
        case discCount
        case discNumber
        case trackCount
        case trackNumber
        case trackTimeMillis
        case country
        case currency
        case primaryGenreName
        case isStreamable
    }
}
