//
//  constance.swift
//  MyMusicBuddy
//
//  Created by Alagarasan Mahalingam on 2/21/19.
//  Copyright © 2019 Alagarasan Mahalingam. All rights reserved.
//

import Foundation

struct Constance {
    var base_url = "https://itunes.apple.com/"
}
